import streamlit as st
import pandas as pd
import numpy as np
import base64
import hmac
import random
import time
import pages

signval = False
st.set_page_config(
    page_title="MediCode",
    layout="wide",
    initial_sidebar_state = "collapsed"
)



def check_password():
    def login_form():       
        # Set text color and shadow
        st.markdown(
            """
            <style>
            .text-shadow {
                text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.5);
                color: white;
            }
            </style>
            """,
            unsafe_allow_html=True,
        )
        # text enter cred 
        st.markdown(
            """
            <style>
            .text-shadow-inside {
                text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.5);
                color: black;
            }
            </style>
            """,
            unsafe_allow_html=True,
        )
        #Transparent gray background color
        st.markdown(
            """
            <style>
            .st-cc-trans {
                background-color: rgba(128, 128, 128, 0.5); /* Transparent gray background color */
                padding: 20px;
                border-radius: 10px;
            }
            </style>
            """,
            unsafe_allow_html=True,
        )

        with st.form("🔐 Log In",clear_on_submit=True):
            st.markdown("<h2 class='text-shadow st-cc-trans'>MediCode: ICD, CPT Code Prediction</h2>", unsafe_allow_html=True)
            st.markdown("<p class='text-shadow-inside'>Please enter your credentials below to access the system.</p>", unsafe_allow_html=True)

            # st.text_input("👤 Username", key="username")
            st.text_input("👤 Username", key="username")
            st.text_input("🔑 Password", type="password", key="password")
            col1, col2 = st.columns([2, 1])
            with col1:
                global signval
                signval = st.form_submit_button("Log In", on_click=password_entered)
            with col2:
                pass
                # st.form_submit_button("Sign Up", on_click=signup_page)

    # def signup_page():
    #     st.session_state["password_correct"] = True

    def password_entered():
        if st.session_state["username"] in st.secrets[
            "passwords"
        ] and hmac.compare_digest(
            st.session_state["password"],
            st.secrets.passwords[st.session_state["username"]],
        ):
            st.session_state["password_correct"] = True
            del st.session_state["password"]
            del st.session_state["username"]
        else:
            st.session_state["password_correct"] = False

    if st.session_state.get("password_correct", False):
        return True

    login_form()
    if "password_correct" in st.session_state:
        st.error("""
                 Invalid Credentials!\n
                 For assistance, kindly reach out to medicode@assist.ai
                 """)
    return False


if __name__ == '__main__':
    if not check_password():
        st.stop()
    else:
        st.switch_page("pages/01_Dashboard.py")

