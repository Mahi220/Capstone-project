import streamlit as st
import random
import pandas as pd
import numpy as np
import os
import collections
import pickle
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import HashingVectorizer
import time
from tqdm import tqdm
import json
import google.generativeai as genai
import requests
from PIL import Image
from transformers import AutoImageProcessor, AutoModelForImageClassification

# st.set_page_config(page_title="Signup", layout="wide")

data_folder = os.path.join(os.getcwd(), "Data")


def take_query1(original_df, x, query, gender_test, age,  Vec):
    input_ = Vec.transform([query])
    cosine = cosine_similarity(input_,x).flatten()
    temp_dataset = original_df.copy()
    temp_dataset['cosine_value'] = cosine
    final_df = temp_dataset[temp_dataset['cosine_value'] >= 0.0]
    final_df = final_df.sort_values(by=['cosine_value'], ascending=False)
    
    default_returns = []
    
        
    for i in final_df.index:
        
        cpt_code_pred = final_df['CPT_CODE'][i]
        cosine_sim = final_df['cosine_value'][i]
        default_returns.append(cpt_code_pred)
        default_returns.append(cosine_sim)
        
        if gender_test == 0 and int(age) == 0:
            return default_returns[0], default_returns[1]

        break
    
    if gender_test != 0:
        final_df1 = final_df[final_df['GENDER_INDICATOR'].isin([gender_test])]
        if final_df1.empty:
            final_df2 = final_df[final_df['AGE_INDICATOR'].isin([age])]

            if final_df2.empty:
                return default_returns[0], default_returns[1]
            else:
                for i in final_df2.index:
                    cpt_code_pred = final_df2['CPT_CODE'][i]
                    cosine_sim = final_df2['cosine_value'][i]
                    if cosine_sim >= 0:
                        return cpt_code_pred, cosine_sim
                    else:
                        return "Description Incomplete", 0.0
        else:
            for i in final_df1.index:
                cpt_code_pred = final_df1['CPT_CODE'][i]
                cosine_sim = final_df1['cosine_value'][i]
                if cosine_sim >= 0:
                    return cpt_code_pred, cosine_sim        
                elif age == 0:
                   return default_returns[0], default_returns[1]

    else:
        final_df1 = final_df.copy()
        final_df3 = final_df[final_df['AGE_INDICATOR'].isin([age])]
        if final_df3.empty:
            return default_returns[0], default_returns[1]
        else:
            for i in final_df3.index:
                cpt_code_pred = final_df3['CPT_CODE'][i]
                cosine_sim = final_df3['cosine_value'][i]
                if cosine_sim >= 0:
                    return cpt_code_pred, cosine_sim
                else:
                    return "Description Incomplete", 0.0

    return "Description Incomplete", 0.0


def cpt_prediction(data96k,x,dia_desc_S, Vec,gender,ageC):
    out, m_cos = take_query1(data96k,x,dia_desc_S,gender,ageC,Vec)
    if m_cos >= 0:
        return out, m_cos
    else:
        return "Description Incomplete", m_cos
    
def take_query(original_df, x, query, Vec):
    input_ = Vec.transform([query])
    cosine = cosine_similarity(input_,x).flatten()
    temp_dataset = original_df.copy()
    temp_dataset['cosine_value'] = cosine
    cosine_max = max(cosine)
    final_df = temp_dataset[temp_dataset['cosine_value'] == cosine_max]
    dc = final_df['DIAGNOSIS_CODE']
    dc_nd = []
    for val in dc:
        v = val.split('.')
        dc_nd.append(v[0])
    cn = collections.Counter(dc)
    cn_nd = collections.Counter(dc_nd)
    max_dc = max(cn, key = lambda x: cn[x])
    max_dc_val = cn[max_dc]
    ambi = []
    for cn_k, cn_v in cn.items():
        if cn_v == max_dc_val:
            ambi.append(cn_v)
        if len(ambi) >= 2:
            max_dc_nd = max(cn_nd, key = lambda x: cn_nd[x])
            for cn_k, cn_v in cn.items():
                cn_k_split = cn_k.split(".")
                if cn_k_split[0] == max_dc_nd:
                    return cn_k, cosine_max
                    break
        else:
            return max_dc, cosine_max    

def icd_prediction(data96k,x,dia_desc_S, Vec):
    out, m_cos = take_query(data96k,x,dia_desc_S, Vec)
    if m_cos >= 0.3:
        return out, m_cos
    else:
        return "Description Incomplete", m_cos

def ConvoAnalysisPrompt(text:str):
    convo_analysis_prompt = f"""Analyse the following Doctor-Patient Conversation '{text}' and generate below:
    1. ICD Code for the symptoms in the conversation.
    2. CPT (Procedure) Code for the symptoms.
    3. Summary of the Doctor-Patient conversation.
    give the result in a elite way
    """
    return convo_analysis_prompt

def CPTPrompt(text:str):
    convo_analysis_prompt = f"""Analyse the following Information contain, symptoms, Gender, Age and CPT Code '{text}' and generate One Insights
    give the result in a elite way
    """
    return convo_analysis_prompt

def ICDPrompt(text:str):
    convo_analysis_prompt = f"""Analyse the following Information contain, symptoms and ICD Code '{text}' and generate One Insights
    give the result in a elite way
    """
    return convo_analysis_prompt

def llm():
    genai.configure(api_key=os.environ["GOOGLE_API_KEY"])
    gemini_model = genai.GenerativeModel("gemini-pro",
                                         generation_config=genai.types.GenerationConfig(
                                             max_output_tokens=64000,
                                             temperature=0.0
                                         ))
    return gemini_model

def responseFunc(prompt):
    model = llm()
    response = model.generate_content(prompt)
    return response


#Helper Function:
def perform_icd_prediction(diseases):
    #ICD Prediction:
    TRAINING_FILE = data_folder + "\\TRAINING\\Training_V2.csv"
    data96k = pd.read_csv(TRAINING_FILE,index_col=False)
    data96k.dropna(axis=0, inplace=True)
    data96k.columns = ['index','OCR_DIAGNOSIS_DESC', 'DIAGNOSIS_CODE']
    Vec = HashingVectorizer()
    x = Vec.fit_transform(data96k['OCR_DIAGNOSIS_DESC'])
    dia_desc_S = diseases
 
    out, _ = icd_prediction(data96k, x, dia_desc_S, Vec)
    icd_code = out
    return icd_code

def perform_cpt_prediction(diseases, age, gender):
    #CPT Prediction
    TRAINING_FILE = data_folder + "\\TRAINING\\Training_CPT.csv"
    data96k = pd.read_csv(TRAINING_FILE,index_col=False)
    Vec = HashingVectorizer()
    x = Vec.fit_transform(data96k['PROCEDURE_DESC'])
    dia_desc_S = str(diseases)
    out, _ = cpt_prediction(data96k, x, dia_desc_S, Vec, gender,age)
    cpt_code = out
    return cpt_code



def icd_code_prediction():
    st.subheader("ICD Code Prediction")
    diseases = st.text_input("Enter diseases (comma-separated)")
    submit_button = st.button("Submit")
    
    if submit_button:
        icd_code = perform_icd_prediction(diseases)
                        #Generate:
        GeminiKeys = [
        "AIzaSyCcVUOyL2M9aNRUhgO6lzTAJ-BjOUXZrt0",
        "AIzaSyC9JxomOkNel9uy0qdqixDcI6UH6KhMcho"
        ]
        text = "Symptoms:"+str(diseases)+ "ICD Code:"+str(icd_code)
        os.environ["GOOGLE_API_KEY"] = GeminiKeys[0]
        prompt = ICDPrompt(text)
        response = responseFunc(prompt)
        llm_response  = response.text    
        st.success(f"Predicted ICD Value: {icd_code}")
        st.success(str(llm_response))


def cpt_code_navigation():
        st.subheader("CPT Code Prediction")
        with st.form(key='cpt_form'):
            diseases = st.text_input("Enter diseases (comma-separated)")
            age = st.number_input("Enter age", min_value=0, max_value=150, step=1)
            gender = st.radio("Select gender", ("Male", "Female"))
            if gender == 'Male':
                genderabbr = 1
            else:
                genderabbr = 2
            submit_button = st.form_submit_button("Submit CPT Prediction")
            if submit_button:
                cpt_code = perform_cpt_prediction(diseases, age, genderabbr)

                #Generate:
                GeminiKeys = [
                "AIzaSyCcVUOyL2M9aNRUhgO6lzTAJ-BjOUXZrt0",
                "AIzaSyC9JxomOkNel9uy0qdqixDcI6UH6KhMcho"
                ]
                text = "Symptoms:"+str(diseases) +", Gender: "+str(gender)+", Age: "+str(age)+", CPT Code:"+str(cpt_code)
                os.environ["GOOGLE_API_KEY"] = GeminiKeys[0]
                prompt = CPTPrompt(text)
                response = responseFunc(prompt)
                llm_response  = response.text
                st.success(f"Predicted CPT Code: {cpt_code}")
                st.success(str(llm_response))


def image_prediction():
    st.subheader("Image Prediction")
    uploaded_file = st.file_uploader("Upload report PDF/image", type=["pdf", "jpg", "png"])
    submit_button = st.button("Submit")
    
    if submit_button and uploaded_file is not None:
        # Perform image prediction (replace this with your actual code)
        # st.success("Image prediction results will be displayed here.")
        label_dict = {
            "0": "benign_keratosis-like_lesions",
            "1": "basal_cell_carcinoma",
            "2": "actinic_keratoses",
            "3": "vascular_lesions",
            "4": "melanocytic_Nevi",
            "5": "melanoma",
            "6": "dermatofibroma"
        }
        # Load the image using PIL
        # image_path = "sk.jpeg"
        image = Image.open(uploaded_file)

        # Initialize the image processor and model
        processor = AutoImageProcessor.from_pretrained("Anwarkh1/Skin_Cancer-Image_Classification")
        model = AutoModelForImageClassification.from_pretrained("Anwarkh1/Skin_Cancer-Image_Classification")

        # Process the image
        inputs = processor(images=image, return_tensors="pt")

        # Perform inference using the model
        outputs = model(**inputs)

        # Print the predicted class
        predicted_class = outputs.logits.argmax().item()
        st.write("Predicted class:")
        st.success(label_dict[str(predicted_class)])
        print("Predicted class:", label_dict[str(predicted_class)])

def doctor_patient_conversation():
    st.subheader("Doctor-Patient Conversation")
    uploaded_file = st.file_uploader("Upload conversation file (vtt/txt)", type=["vtt", "txt"])
    submit_button = st.button("Submit")
    
    if submit_button and uploaded_file is not None:
        if uploaded_file.type == "text/plain":
            # Get the content of the uploaded file as bytes
            file_contents = uploaded_file.getvalue()
            # Decode the bytes to convert them into a string
            conversation_text = file_contents.decode("utf-8")
            GeminiKeys = [
                "AIzaSyCcVUOyL2M9aNRUhgO6lzTAJ-BjOUXZrt0",
                "AIzaSyC9JxomOkNel9uy0qdqixDcI6UH6KhMcho"
            ]
            os.environ["GOOGLE_API_KEY"] = GeminiKeys[0]
            prompt = ConvoAnalysisPrompt(conversation_text)
            response = responseFunc(prompt)
            llm_response  = response.text


            
            # Display the conversation text
            st.success(llm_response)
        else:
            st.error("Please upload a text file (txt).")
        # with open(uploaded_file, 'r') as file:
        #     # Read the content of the file into a string variable
        #     conversation_text = file.read()
        #     st.success(conversation_text)

# Main content
st.set_page_config(page_title="Medical Coding App", layout="wide")

st.title("Medical Coding App")
st.markdown("---")

st.sidebar.title("Options")
selected_option = st.sidebar.radio("Select an option", ["ICD Code Prediction", "CPT Code Prediction","Image Prediction", "Doctor-Patient Conversation"])

if selected_option == "ICD Code Prediction":
    icd_code_prediction()
elif selected_option == "CPT Code Prediction":
    cpt_code_navigation()
elif selected_option == "Image Prediction":
    image_prediction()
elif selected_option == "Doctor-Patient Conversation":
    doctor_patient_conversation()
